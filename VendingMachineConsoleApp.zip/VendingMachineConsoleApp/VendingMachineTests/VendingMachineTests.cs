using System;
using NUnit.Framework;
using VendingMachineConsoleApp;

namespace VendingMachineTests
{
    [TestFixture]
    public class VendingMachineTests
    {
        private VendingMachine vendingMachine;

        [SetUp]
        public void Setup()
        {
            vendingMachine = new VendingMachine();
            vendingMachine.Initialize();
        }

        [Test]
        public void InsertValidCoins_UpdateBalanceAndDisplay()
        {
            vendingMachine.InsertCoin(5.0, 21.2); // Nickel
            vendingMachine.InsertCoin(2.27, 17.9); // Dime
            vendingMachine.InsertCoin(5.67, 24.3); // Quarter

            Assert.AreEqual(40, vendingMachine.CurrentBalanceInCents); // 5 + 10 + 25
            Assert.AreEqual("Current Balance: 40 cents", vendingMachine.DisplayMessage());
        }

        [Test]
        public void InsertInvalidCoin_RejectAndDisplayMessage()
        {
            vendingMachine.InsertCoin(2.5, 19.0); // Invalid coin

            Assert.AreEqual(0, vendingMachine.CurrentBalanceInCents);
            Assert.AreEqual("Invalid coin. Coin returned.", vendingMachine.DisplayMessage());
        }

        [Test]
        public void SelectProduct_InsufficientBalance_DisplayPrice()
        {
            vendingMachine.InsertCoin(5.67, 24.3); // Quarter
            vendingMachine.SelectProduct(1); // Select Cola (price: 100 cents)

            Assert.AreEqual(25, vendingMachine.CurrentBalanceInCents);
            Assert.AreEqual("PRICE: 100 cents", vendingMachine.DisplayMessage());
        }

        [Test]
        public void SelectProduct_EnoughBalance_DisplaysThankYou()
        {
            vendingMachine.InsertCoin(5.67, 24.3); // Quarter
            vendingMachine.InsertCoin(5.67, 24.3); // Quarter
            vendingMachine.SelectProduct(2); // Select Chips (price: 50 cents)

            Assert.AreEqual(50, vendingMachine.CurrentBalanceInCents);
            Assert.AreEqual("THANK YOU", vendingMachine.DisplayMessage());
        }

        [Test]
        public void ReturnCoins_EmptiesInsertedCoinsAndUpdatesDisplay()
        {
            vendingMachine.InsertCoin(5.0, 21.2); // Nickel
            vendingMachine.InsertCoin(2.27, 17.9); // Dime
            vendingMachine.ReturnCoins();

            Assert.AreEqual(0, vendingMachine.CurrentBalanceInCents);
            Assert.AreEqual("Coins returned.", vendingMachine.DisplayMessage());
        }

        [Test]
        public void DisplayMessageAfterTransaction()
        {
            vendingMachine.InsertCoin(5.67, 24.3); // Quarter
            vendingMachine.SelectProduct(1); // Select Cola (price: 100 cents)
            vendingMachine.DisplayMessage(); // Display message after a transaction

            Assert.AreEqual("INSERT COINS", vendingMachine.DisplayMessage());
        }
    }
}
