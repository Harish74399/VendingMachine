﻿using System;
using VendingMachineConsoleApp.Model;

namespace VendingMachineConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            VendingMachine vendingMachine = new VendingMachine();
            vendingMachine.Initialize();

            while (true)
            {
                Console.Clear();
                Console.WriteLine($"Current Balance: {vendingMachine.CurrentBalanceInCents} cents");
                vendingMachine.DisplayMessage();

                Console.WriteLine("\n1. Insert Coin");
                Console.WriteLine("2. Select Product");
                Console.WriteLine("3. Return Coins");
                Console.WriteLine("4. Exit");
                Console.Write("Select an option: ");

                string input = Console.ReadLine();

                switch (input)
                {
                    case "1":
                        Console.Write("Enter coin weight (grams): ");
                       // double weight = double.Parse(Console.ReadLine());
                        Console.Write("Enter coin size (mm): ");
                       // double size = double.Parse(Console.ReadLine());
                        //vendingMachine.InsertCoin(weight, size);
                        break;
                    case "2":
                        vendingMachine.DisplayProducts();
                        Console.Write("Select product (1-3): ");
                        int productNumber = int.Parse(Console.ReadLine());
                        vendingMachine.SelectProduct(productNumber);

                       
                        // vendingMachine.ReturnCoins();
                        while (vendingMachine.displayMessage != "THANK YOU")
                        {
                            Console.Write("Enter coin weight (grams): ");
                            double weight = double.Parse(Console.ReadLine());
                            Console.Write("Enter coin size (mm): ");
                            double size = double.Parse(Console.ReadLine());
                            vendingMachine.InsertCoin(weight, size);
                            Console.WriteLine(vendingMachine.DisplayMessage());

                            CheckProductPricewithCoins(vendingMachine, productNumber);
                            Console.WriteLine(vendingMachine.DisplayMessage());
                        }
                       
                        break;
                    case "3":
                        vendingMachine.ReturnCoins();
                        break;
                    case "4":
                        Environment.Exit(0);
                        break;
                    default:
                        Console.WriteLine("Invalid option. Please try again.");
                        break;
                }

                Console.WriteLine("\nPress any key to continue...");
                Console.ReadKey();
            }
        }

        private static void CheckProductPricewithCoins(VendingMachine vendingMachine, int productNumber)
        {
            Product selectedProduct = vendingMachine.products[productNumber - 1];

            if (vendingMachine.currentBalanceInCents >= selectedProduct.PriceInCents)
            {
                vendingMachine.displayMessage = "THANK YOU";
                vendingMachine.currentBalanceInCents -= selectedProduct.PriceInCents;
            }
            else
            {
                vendingMachine.displayMessage = $"PRICE: {selectedProduct.PriceInCents} cents";
            }
        }
    }
}
