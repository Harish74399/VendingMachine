﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VendingMachineConsoleApp.Model;
using VendingMachineConsoleApp.Enums;

namespace VendingMachineConsoleApp
{
   public class VendingMachine
    {
        public List<Product> products;
        public List<Coin> insertedCoins;
        public int currentBalanceInCents;
        public string displayMessage;

        public int CurrentBalanceInCents => currentBalanceInCents;

        public void Initialize()
        {
            products = new List<Product>
            {
                new Product { Name = "Cola", PriceInCents = 100 },
                new Product { Name = "Chips", PriceInCents = 50 },
                new Product { Name = "Candy", PriceInCents = 65 }
            };

            insertedCoins = new List<Coin>();
            currentBalanceInCents = 0;
            displayMessage = "INSERT COINS";
        }

        public void DisplayProducts()
        {
            Console.WriteLine("\nAvailable Products:");
            for (int i = 0; i < products.Count; i++)
            {
                Console.WriteLine($"{i + 1}. {products[i].Name} - {products[i].PriceInCents} cents");
            }
        }

        public string DisplayMessage()
        {
            //Console.WriteLine($"\n{displayMessage}");
            return displayMessage;


        }

        public void InsertCoin(double weight, double size)
        {
            Coin coin = IdentifyCoin(weight, size);
            if (coin != null)
            {
                insertedCoins.Add(coin);
                currentBalanceInCents += GetValueForCoin(coin.Type);
                displayMessage = $"Current Balance: {currentBalanceInCents} cents";
            }
            else
            {
                displayMessage = "Invalid coin. Coin returned.";
            }
        }

        public void SelectProduct(int productNumber)
        {
            if (productNumber > 0 && productNumber <= products.Count)
            {
                Product selectedProduct = products[productNumber - 1];

                if (currentBalanceInCents >= selectedProduct.PriceInCents)
                {
                    displayMessage = "THANK YOU";
                    currentBalanceInCents -= selectedProduct.PriceInCents;
                }
                else
                {
                    displayMessage = $"PRICE: {selectedProduct.PriceInCents} cents";
                }
            }
            else
            {
                displayMessage = "Invalid product number.";
            }
        }

        public void ReturnCoins()
        {
            foreach (Coin coin in insertedCoins)
            {
                currentBalanceInCents -= GetValueForCoin(coin.Type);
            }
            insertedCoins.Clear();
            displayMessage = "Coins returned.";
        }

        private Coin IdentifyCoin(double weight, double size)
        {
            if (Math.Abs(weight - 5.0) < 0.5 && Math.Abs(size - 21.2) < 1.0)
            {
                return new Coin { Type = CoinType.Nickel };
            }
            else if (Math.Abs(weight - 2.27) < 0.5 && Math.Abs(size - 17.9) < 1.0)
            {
                return new Coin { Type = CoinType.Dime };
            }
            else if (Math.Abs(weight - 5.67) < 0.5 && Math.Abs(size - 24.3) < 1.0)
            {
                return new Coin { Type = CoinType.Quarter };
            }
            return null;
        }

        private int GetValueForCoin(CoinType coinType)
        {
            switch (coinType)
            {
                case CoinType.Nickel:
                    return 5;
                case CoinType.Dime:
                    return 10;
                case CoinType.Quarter:
                    return 25;
                default:
                    return 0;
            }
        }
    }
}
