﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VendingMachineConsoleApp.Enums;

namespace VendingMachineConsoleApp.Model
{
   public class Coin
    {
        public double Weight { get; set; }
        public double Size { get; set; }
        public CoinType Type { get; set; }
    }
}
